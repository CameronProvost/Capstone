window.CPPool243Init = function() { cp.model['243Data']={
};cp.poolSlideResources['pool243']={
};
cp.model.data['243']={
pqs:[],
gqs:[],
sqs:[],
rgqs:[],
rsqs:[],
hasCC:false
};
cp.poolResources["243Images"]=[];
cp.poolResources["243Videos"]=[
];
cp.poolResources["243SlideVideos"]=[
];
}